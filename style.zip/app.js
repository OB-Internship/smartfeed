angular.module('myApp', ['ui.bootstrap', 'as.sortable', 'ngSQLite'])
    .controller('myCtrl', function($scope, $SQLite) {
        var i;
        $scope.itemsList = {
            items1: [],
            items2: []
        };

        var modal = document.getElementById('myModal');

        $scope.itemsList.items1.push({ Id: 1, Label: 'Paid Link', Page: 'PaidLink' });
        $scope.itemsList.items1.push({ Id: 4, Label: 'Organic Link', Page: 'OrganicLink' });
        $scope.itemsList.items1.push({ Id: 3, Label: 'Paid Video', Page: 'PaidVideo' });
        $scope.itemsList.items1.push({ Id: 2, Label: 'Organic Video', Page: 'OrganicVideo' });
        $scope.itemsList.items1.push({ Id: 5, Label: 'Programmatic', Page: 'Programmatic' });
        $scope.itemsList.items1.push({ Id: 6, Label: 'Best of Web', Page: 'BestOfWeb' });
        $scope.itemsList.items1.push({ Id: 7, Label: 'Subscriptions', Page: 'Subscriptions' });
        $scope.itemsList.items1.push({ Id: 8, Label: 'Comments', Page: 'Comments' });
        $scope.itemsList.items1.push({ Id: 9, Label: 'Placement', Page: 'Placement' });

        $scope.itemsList.items2.push({ Id: 9, Label: 'Placement', Page: 'Placement' });

        $scope.sortableOptions = {
            containment: '#sortable-container',
            allowDuplicates: true
        };

        $scope.sortableCloneOptions = {
            containment: '#sortable-container',
            clone: true
        };

        $scope.closeItem = function(index) {
            $scope.itemsList.items2.splice(index, 1);
        }

        $scope.items = ['item1', 'item2', 'item3'];

        $scope.reset = function(ev) {
            modal.style.display = "block";
        }

        $scope.close = function() {
            modal.style.display = "none";
        }

        $scope.yes = function() {
            $scope.itemsList.items2 = [];
            $scope.itemsList.items2.push({ Id: 9, Label: 'Placement', Page: 'Placement' });
            modal.style.display = "none";
        }

        localStorage.removeItem('order');
        $scope.save = function() {
            localStorage.setItem('order', JSON.stringify($scope.itemsList.items2));
            // $SQLite.ready(function() {
            //     this.execute('DELETE FROM card_order;') // this.replace
            //         //.then(onResult, onError)
            // });
            // if ($scope.itemsList.items2.length > 0) {
            //     for (let index = 0; index < $scope.itemsList.items2.length; index++) {
            //         const item = $scope.itemsList.items2[index];
            //         var insert_data = { Id: item.Id, Label: item.Label, Page: item.Page };
            //         $SQLite.ready(function() {
            //             this.insert('card_order', insert_data) // this.replace
            //                 //.then(onResult, onError)
            //         });
            //     }
            // }
            document.getElementById('render-frame').contentWindow.location.reload();
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

    });
// }).constant('DB_CONFIG', {
//     card_order: {
//         Id: { type: 'integer' },
//         Label: { type: 'text' },
//         Page: { type: 'text' }
//     },
// }).run(function($SQLite) {
//     $SQLite.dbConfig({
//         name: 'my-browser-db',
//         description: 'Test DB',
//         version: '1.0'
//     });
// }).run(function($SQLite, DB_CONFIG) {
//     $SQLite.init(function(init) {
//         angular.forEach(DB_CONFIG, function(config, name) {
//             init.step();
//             $SQLite.createTable(name, config).then(init.done);
//         });
//         init.finish();
//     });
// });